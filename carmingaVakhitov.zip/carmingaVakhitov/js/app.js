jQuery(document).ready(function () {
    var api = new wkda_api('webclient-040-wkda-de-1205d89');
    var query = {};

    //Getting makes
    api.getMakes().then(function (result) {
        //Put makes to select
        console.log(createOptions(result.wkda));
        let firstItem = jQuery('#selectMarke').html();
        jQuery('#selectMarke').html(createOptions(firstItem, result.wkda));
    }, function(){
        console.log('somehting wrong')
    });


    //Getting models
    jQuery('#selectMarke').on('change', function () {
        let select = jQuery(this).val();
        query.make = select;
        api.getModels(query).then(function(result){
            console.log(result);
            let firstItem = jQuery('#selectModels').html();
            jQuery('#selectModels').html(createOptions(firstItem,result.wkda));
        }, function(){});
    });

    //Getting years
    jQuery('#selectModels').on('change', function(){
        let select = jQuery(this).val();
            query.model = select;
        api.getYears(query).then(function(result){

            //Put years to select
            let firstItem = jQuery('#selectYears').html();
            jQuery('#selectYears').html(createOptions(firstItem,result.wkda));
        }, function(){});
    });

    //Getting body
    jQuery('#selectYears').on('change', function(){
        query.year = jQuery(this).val();
        api.getBody(query).then(function(result){

            //put stage tow
            jQuery('#stageOne').css('margin-top', '-231px').css('opacity', 0);
            jQuery('#stageOne').after(getStageTwo());
            //jQuery read added stage
            let stageTwo = jQuery('#form').children('#stageTow');
            //Put body to select
            let firstItem = jQuery('#selectBodyType').html();
            jQuery('#selectBodyType').html(createOptions(firstItem,result.wkda));

        },function(){});
    });


    //Getting modification
    jQuery('#form').on('change','#selectBodyType', function(){
        query.body = jQuery(this).val();
        api.getDetails(query).then(function(result){
            let firstItem = jQuery('#selectModification').html();
            jQuery('#selectModification').html(createOptions(firstItem,result.wkda));
        },function(){});
    });


    //Getting TypeDetails
    jQuery('#form').on('change','#selectModification', function(){
        query.variant = jQuery(this).val();
        api.getDetails(query).then(function(result){
            let firstItem = jQuery('#selectType').html();
            jQuery('#selectType').html(createOptions(firstItem,result.wkda));
        },function(){});
    });

    //Select Mileage
    jQuery('#form').on('change','#selectMileage', function(){
        query.mileage = jQuery(this).val();
    });

    jQuery('#submitBtn').click(function(){
        let form = jQuery('#form');
        // console.log(form.serialize());
        console.log(JSON.stringify(toJSONString(document.getElementById('form'))));
            // let data = {
            //     car-data: query,
            //     cid:"",
            //     dlp
            // }


    });


});

function createOptions(firstItem, collection){
    let options = firstItem;
    for(key in collection){
        options  += '<option value="'+key+'">' + collection[key] +'</option>';
    }
    return options;
}

function getStageTwo() {
    return '<div id="stageTow">\n' +
        '                            <div class="select-wrapper">\n' +
        '                                <select class="form-control" name="body" id="selectBodyType">\n' +
        '                                    <option selected="">Bauform</option>\n' +
        '\n' +
        '                                </select>\n' +
        '                            </div>\n' +
        '                            <div class="select-wrapper">\n' +
        '\n' +
        '                                <select class="form-control" name="variant" id="selectModification">\n' +
        '                                    <option selected="">Modellvariante</option>\n' +
        '                                </select>\n' +
        '                            </div>\n' +
        '                            <div class="select-wrapper">\n' +
        '\n' +
        '                                <select class="form-control" name="type" id="selectType">\n' +
        '                                    <option selected="">Typ</option>\n' +
        '                                </select>\n' +
        '                            </div>\n' +
        '                            <div class="select-wrapper">\n' +
        '\n' +
        '                                <select class="form-control" name="mileage" id="selectMileage">\n' +
                                                '<option value="" selected="">bitte Kilometerstand wählen</option>' +
                                                '<option value="5000">Bis 5.000</option>' +
                                                '<option value="10000">Bis 10.000</option>' +
                                                '<option value="20000">Bis 20.000</option>' +
                                                '<option value="30000">Bis 30.000</option>' +
                                                '<option value="40000">Bis 40.000</option>' +
                                                '<option value="60000">Bis 60.000</option>' +
                                                '<option value="80000">Bis 80.000</option>' +
                                                '<option value="100000">Bis 100.000</option>' +
                                                '<option value="125000">Bis 125.000</option>' +
                                                '<option value="150000">Bis 150.000</option>' +
                                                '<option value="200000">Mehr als 150.000</option>' +
        '                                </select>\n' +
        '                            </div>\n' +
        '                            <div class="select-wrapper">\n' +
        '                                <input type="email" name="email" placeholder="Mail-Adresse" id="inputEmail">\n' +
        '                            </div>\n' +
        '                        </div>';
}

function toJSONString(form) {
    var obj = {};
    var elements = form.querySelectorAll('input, select, textarea');

    for (var i = 0; i < elements.length; ++i) {
        console.log(element);
        var element = elements[i];
        console.log(element.name);
        var name = element.name;
        var value = element.value;

        if (name) {
            obj[name] = value;
        }
    }
    return obj;
}






